CREATE TABLE CUSTOMER (
  
    CUSTOMER_ID INTEGER PRIMARY KEY,
    FIRST_NAME VARCHAR2(25),
    LAST_NAME VARCHAR2(25),
    EMAIL VARCHAR2(40) UNIQUE

);


CREATE TABLE SEATHOLD (

  SEATHOLD_ID INTEGER PRIMARY KEY,
  CUSTOMER_ID INTEGER,
  
  FOREIGN KEY (CUSTOMER_ID)
  REFERENCES CUSTOMER(CUSTOMER_ID)

);

CREATE TABLE SEATS (

  SEAT_ID INTEGER PRIMARY KEY,
  SEAT_NAME VARCHAR2(3), 
  AVAILABILITY VARCHAR2(1),
  SEATHOLD_ID INTEGER,
  
  FOREIGN KEY (SEATHOLD_ID)
  REFERENCES SEATHOLD(SEATHOLD_ID)

);


CREATE SEQUENCE SEATHOLD_ID_SEQ
INCREMENT BY 1
START WITH 1000;

CREATE SEQUENCE SEAT_ID_SEQ
INCREMENT BY 1
START WITH 3000;

CREATE SEQUENCE CUSTOMER_ID_SEQ
INCREMENT BY 1
START WITH 10000;


insert into Customer
values(CUSTOMER_ID_SEQ.nextval, 'ZEBRATHEATER', '', 'ZEBRATHEATER@gmail.com');

insert into Customer
values(CUSTOMER_ID_SEQ.nextval, 'John', 'Doe', 'JohnDoe@gmail.com');

insert into Customer
values(CUSTOMER_ID_SEQ.nextval, 'Poe', 'Panda', 'PoePanda@gmail.com');

insert into Customer
values(CUSTOMER_ID_SEQ.nextval, 'Chris', 'Ramos', 'Chris_Ramos_34@yahoo.com');

insert into Customer
values(CUSTOMER_ID_SEQ.nextval, 'Bacon', 'Sandwich', 'baconsandwich@gmail.com');