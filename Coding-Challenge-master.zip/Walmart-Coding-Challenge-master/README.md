# Walmart-Coding-Challenge
This repo is for the Walmart coding challenge

Technical Assumptions:

- Reviewers will have access to Oracle SQL Developer 4.1.3
- Reviewers will have access to Apache TomCat version 8.0.39
- Reviewers will have access Maven 3.3.9

Challege Assumptions:

- The ticket service is for a Movie Theater 
- There is only one showing room in the Theater
- Only one person can access the ticket service at a time
- If no one is holding a seat then the Theater is "holding" it as available
- Anyone using the ticket service is assumed to be registered in the database
  prior to using the ticket service
- The venue has 9 x 30 seats in it
  
Pre Application Steps

1. Install all of the necessary technologies
2. Run the SQL scripts in the following order
  - DatabaseCredentials.sql
  - DBSchema.sql
  - LoopToCreateSeats.sql
  

Application Process

1. copy and paste this URL http://localhost:8080/ZebraMovies/JSP/index.jsp into you browser
   once you have started a local server
2. Next click the login link to navigate to the login page
3. There you will type up an email (in this application it is case-sensitive) which will
   effectively act as a password and username
   
   choose from the list below:
   
   - baconsandwich@gmail.com
   - PoePanda@gmail.com
   - JohnDoe@gmail.com
   
4. From there you will be redirected to the homepage and navigate to the seat selection page
5. Once at the Seat selection page you can choose from seats that you would like to claim
6. After choosing the desired (and available) seats press the submit button to send a request to
   the database claiming those seats









