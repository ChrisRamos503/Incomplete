package com.zebra.model;

import java.util.ArrayList;
import java.util.List;

import com.zebra.dao.CustomerDAO;
import com.zebra.dao.SeatDAO;
import com.zebra.dao.SeatHoldDAO;
import com.zebra.service.TicketService;

/*
 * 
 * initially I was going to treat this class as
 * a pojo, but I thought it would be better 
 * suited to implementing the TicketService interface
 * 
 */



public class Venue implements TicketService{
	
	// work around for holding desired seats
	static List<Seat> SeatContainer;
	
	public int numSeatsAvailable() {
		
		int num = 0;
		
		SeatDAO sdao = new SeatDAO();
		
		num = sdao.getAvailableSeatCount();
		
		return num;
	}

	
	// creates a seathold associated with customer
	public SeatHold findAndHoldSeats(int numSeats, String customerEmail) {
		
		SeatHold sh = null;
		
		if(numSeatsAvailable() >= numSeats){ 
			
			//get customer from database
			CustomerDAO cdao = new CustomerDAO();
			Customer c = cdao.getCustomer(customerEmail);
			
			SeatHoldDAO shdao = new SeatHoldDAO();
			
			//create seathold object
			sh = shdao.createSeatHold(c.getCustomerID());
		}
		
		return sh;
	}

	
	// updates seats status to Reserved
	public String reserveSeats(int seatHoldId, String customerEmail) {
		
		SeatDAO sdao = new SeatDAO();
		
		String str = "";
		
		/* loop through list of seats that
		   that customer has claimed and save
		   them to the database
		*/
		for(Seat s : SeatContainer){
			
			s.setSeatHold(seatHoldId);
			s.setStatus('R');
			sdao.updateSeat(s);
			
		}
		
		
		return str;
	}
	
	
	//saves ids of chosen seats to the objects own list
	public void grabSeatsFromCollection(List<Seat> seatList, String[] index){
		
		SeatContainer = new ArrayList<Seat>();
		
		
		/* get the indices of the seats in the list and add the
		   and add the seats that have been selected by the user
		   to the new list
		*/
		for(String s : index){
			
			SeatContainer.add(seatList.get(Integer.parseInt(s)) );
			
		}
		
	}
	
	
}
