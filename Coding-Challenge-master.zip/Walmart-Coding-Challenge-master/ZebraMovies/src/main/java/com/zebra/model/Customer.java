package com.zebra.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/*
 * Used to store information about customer such as
 * id, first and last name, and email
 * 
 */

@Entity
@Table(name = "Customer")
public class Customer {
	
	@Id
	@Column(name = "customer_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customer_generator")
	@SequenceGenerator(name="customer_generator", sequenceName = "CUSTOMER_ID_SEQ")
	private int customerID;
	
	@Column(name = "email")
	private String customerEmail;
	
	@Column(name = "first_name")
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	public Customer(int customerID, String customerEmail, String firstName, String lastName) {
		super();
		this.customerID = customerID;
		this.customerEmail = customerEmail;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public Customer(){
		
	}
	
	
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", customerEmail=" + customerEmail + ", firstName=" + firstName
				+ ", lastName=" + lastName + "]";
	}
	
	
	

}
