package com.zebra.config;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
//import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.service.ServiceRegistry;

/*
 * This class is used to configure Hibernate
 * and grab sessions from the session factory
 * 
 */

public class DatabaseConfig {
	
	//static Configuration config;
	static private SessionFactory Factory;
	
	static{DatabaseConfig.initializeConfig();}
	
	
	/*
	 *
	 * Configure Hibernate session factory 
	 *  with hibernate properties file
	 * 
	 */
	
	public static void initializeConfig(){
		
		Factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.buildSessionFactory();	
	}
	
	
	/*
	 * 
	 * Returns a session from the session from
	 * the sessionFactory
	 */
	
	public static Session retreiveSession(){
		
		return Factory.getCurrentSession();
	}

}
