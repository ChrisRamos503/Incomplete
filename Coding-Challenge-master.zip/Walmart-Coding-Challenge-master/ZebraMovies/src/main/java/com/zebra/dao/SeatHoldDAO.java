package com.zebra.dao;

import org.hibernate.Session;

import com.zebra.config.DatabaseConfig;
import com.zebra.model.SeatHold;

/*
 * intended to create SeatHold entries in the database
 * and perform other CRUD activites
 */

public class SeatHoldDAO {
	
	
	// creates a seat hold object
	public SeatHold createSeatHold(int CustomerID){
		
		SeatHold sh = new SeatHold();
		
		Session session = DatabaseConfig.retreiveSession();
		
		sh.setCustomerID(CustomerID);
		
		session.beginTransaction();
		
		session.save(sh);
		session.getTransaction().commit();
		
		session.close();
		
		return sh;
	}
	
	public void updateSeatHold(SeatHold sh){
		// unimplemented
	}
	
	public void getSeatHold(SeatHold sh){
		// unimplemented
	}
	
	public void deleteSeatHold(SeatHold sh){
		// unimplemented
	}
	
	

}
