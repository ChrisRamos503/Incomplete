package com.zebra.service;

import com.zebra.model.SeatHold;

/*
 * The challenge 
 */

public interface TicketService {
	
	int numSeatsAvailable();
	
	SeatHold findAndHoldSeats(int numSeats, String customerEmail);
	
	String reserveSeats(int seatHoldId, String customerEmail);
	
	
	
	
}
