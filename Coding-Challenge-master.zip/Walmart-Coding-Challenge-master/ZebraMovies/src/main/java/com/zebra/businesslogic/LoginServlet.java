package com.zebra.businesslogic;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zebra.dao.CustomerDAO;
import com.zebra.model.SeatHold;
import com.zebra.model.Venue;

@WebServlet("/login")


/*
 * 
 * This servlet is dedicated to logging in a user
 * or in this case fetch a customer from the database
 * to create a seathold
 * 
 */

public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		CustomerDAO cdao = new CustomerDAO();
		
		HttpSession session = req.getSession();
		
		//retrieve email from form
		String email = req.getParameter("email");
		
		Venue ven = new Venue();
		
		// create seathold
		SeatHold sh = ven.findAndHoldSeats(1, email);

		// store seathold ID for later use
		session.setAttribute("SeatHoldID", sh.getSeatHoldID());
		
		resp.sendRedirect("JSP/index.jsp");

	}
	
	
}
