package com.zebra.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 *
 * This class is used to store CustomerID and
 * SeatHoldID so that a claim to seats can 
 * be linked back to customer
 *
 */

@Entity
@Table(name = "seathold")
public class SeatHold {
	
	@Id
	@Column(name = "SeatHold_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seat_generator")
	@SequenceGenerator(name="seat_generator", sequenceName = "SEATHOLD_ID_SEQ")
	private int seatHoldID;
	
	@Column(name = "customer_id")
	private int customerID;
	
	
	public SeatHold(int seatHoldID, int customerID) {
		super();
		this.seatHoldID = seatHoldID;
		this.customerID = customerID;
	}
	
	public SeatHold(){
		
	}
	
	public int getSeatHoldID() {
		return seatHoldID;
	}


	public void setSeatHoldID(int seatHoldID) {
		this.seatHoldID = seatHoldID;
	}

	public int getCustomerID() {
		return customerID;
	}


	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}


	@Override
	public String toString() {
		return "SeatHold [seatHoldID=" + seatHoldID + ", customerID=" + customerID + "]";
	}
	
	
	
	
	
	
}
