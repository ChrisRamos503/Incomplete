package com.zebra.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.zebra.config.DatabaseConfig;
import com.zebra.model.Seat;

/*
 * intended to create Seat entries in the database
 * and perform other CRUD activites
 */

public class SeatDAO {

	
	public void createSeat(){
		//unimplemented
	}
	
	
	// retrieves the number of seats that are Available
	public int getAvailableSeatCount(){
		
		int count = 0;
		long lc = 0;
		
		Session session = DatabaseConfig.retreiveSession();

		session.beginTransaction();
				
		// fetch number of seats where status = available
		Criteria criteria = session.createCriteria(Seat.class);
		criteria.add(Restrictions.eq("status", 'A'));
		criteria.setProjection(Projections.rowCount());
		
		// extract Number object
		Number numRows = (Number)criteria.uniqueResult();
		
		// cast it to a long
		lc =  (long) numRows;
		
		// cast the long to an int
		count = (int) lc;
		
		session.close();
		
		return count;
	}
	
	
	// retrieves all seats from the Database
	public List<Seat> getSeats(){
		
		Session session = DatabaseConfig.retreiveSession();
		
		List<Seat> seatList = null;

		session.beginTransaction();
		
		// fetch all of the seats
		seatList = (ArrayList<Seat>) session.createQuery("from Seat")
				.getResultList();
		
		session.close();
		
		return seatList;
		
	}
	
	
	public void getSeat(int id){
		//unimplemented}
	}
	
	 // Used to update seat statuses
	public void updateSeat(Seat seat){
		
		Session session = DatabaseConfig.retreiveSession();
		
		Transaction tx = session.beginTransaction();
		
		session.update(seat);
		
		tx.commit();
		
		session.close();
		
		
	}
	
	public void deleteSeat(int id){
		//unimplemented
	}
	
	
	
}
