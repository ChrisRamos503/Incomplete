package com.zebra.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/*
 * Used to store information about seats such
 * as id, Seathold ID, seat name, and claim status
 * 
 */

@Entity
@Table(name = "Seats")
public class Seat {
	
	@Id
	@Column(name = "Seat_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seat_generator")
	@SequenceGenerator(name="seat_generator", sequenceName = "SEAT_ID_SEQ")
	private int seatID;
	
	@Column(name = "Seat_Name")
	private String seatName;
	
	@Column(name = "Availability")
	private char status;
	
	@Column(name = "SeatHold_ID")
	private int seatHold;
	
	
	public Seat(int seatID, String seatName, char status, int seatHold) {
		super();
		this.seatID = seatID;
		this.seatName = seatName;
		this.status = status;
		this.seatHold = seatHold;
	}
	
	public Seat(){
		
	}

	public int getSeatID() {
		return seatID;
	}

	public void setSeatID(int seatID) {
		this.seatID = seatID;
	}

	public String getSeatName() {
		return seatName;
	}

	public void setSeatName(String seatName) {
		this.seatName = seatName;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public int getSeatHold() {
		return seatHold;
	}

	public void setSeatHold(int seatHold) {
		this.seatHold = seatHold;
	}

	@Override
	public String toString() {
		return "Seat [seatID=" + seatID + ", seatName=" + seatName + ", status=" + status + ", seatHold=" + seatHold
				+ "]";
	}
	

	
	
	
}
