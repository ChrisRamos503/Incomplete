package com.zebra.businesslogic;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/GrabSeats")

public class ReserveSeatsServlet extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String SeatIDs[] = req.getParameterValues("SeatIDArray");
		
		System.out.println(SeatIDs);
		
		if(SeatIDs == null){
			
			System.out.println("this can't be!!!!!!!!");
		}

		
	}

}
