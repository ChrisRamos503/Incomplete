package com.zebra.businesslogic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zebra.model.Seat;
import com.zebra.model.SeatHold;
import com.zebra.model.Venue;

@WebServlet("/SendIDs")

/*
 * This servlet is dedicated to saving
 * a customer's seat claims
 */

public class SeatIDServlet extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		// used to get String of IDs out of request
		// and into array for conversion later on
		String[] ids = req.getParameter("str_data").split(",");
		
		HttpSession session =   req.getSession();
		
		// grab seat list that was saved previously
		List<Seat> seatList =  (ArrayList<Seat>) session.getAttribute("seatList");
		
		Venue ven = new Venue();
		
		
		ven.grabSeatsFromCollection(seatList, ids);
		
		// Auto-unbox the session attributes
		// update the seats in the database 
		ven.reserveSeats( (Integer) session.getAttribute("SeatHoldID"), (String) session.getAttribute("email"));
		 
		
	}

}
