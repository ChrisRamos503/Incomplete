package com.zebra.main;

import com.zebra.config.DatabaseConfig;
import com.zebra.dao.SeatDAO;
import com.zebra.dao.SeatHoldDAO;

public class Main {

	public static void main(String[] args){
		
		System.out.println("hello there from main");	
	}
	
	
	
	
	
	
	
}
