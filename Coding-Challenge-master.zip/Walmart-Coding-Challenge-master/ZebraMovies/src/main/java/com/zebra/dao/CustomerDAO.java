package com.zebra.dao;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.zebra.config.DatabaseConfig;
import com.zebra.model.Customer;

/*
 * intended to create Customer entries in the database
 * and perform other CRUD activites
 */

public class CustomerDAO {
	
	public boolean createCustomer(){
		
		// unimplemented
		
		return false;
	}
	
	//fetches a customer by email
	public Customer getCustomer( String email ){
		
		Customer c = null;
		
		Session session = DatabaseConfig.retreiveSession();
		
		session.beginTransaction();
		
		//fetch customer where customer.email = customer
		c = (Customer) session.createQuery("from Customer where customerEmail = :email ")
				.setParameter("email", email)
				.getSingleResult();
		
		session.close();
		
		return c;
	}
	
	public void getCustomerByID(){
		
		// unimplemented
	}
	
	public boolean updateCustomer(Customer customer){
		
		// unimplemented
		return false;
	}
	
	public boolean deleteCustomer(Customer customer){
		// unimplemented
		return false;
	}
	
	
	
	
	
	
	
	

}
