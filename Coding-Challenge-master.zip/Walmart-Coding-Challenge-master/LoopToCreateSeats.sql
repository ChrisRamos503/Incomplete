
-- this bit of SQL is used to create and insert seats into the 
-- database assuming they haven't be created yet


declare 

-- just declaring a letter array
theater_row_letters sys.dbms_debug_vc2coll
  := sys.dbms_debug_vc2coll('A','B','C','D','E','F','G','H','I');

begin

  -- iterate through the letter array
  for r in theater_row_letters.first..theater_row_letters.last
    loop

      -- iterating through the number of columns and appending
      -- a letter with number to create a name for the seat
      FOR i IN 1..30 LOOP 
       
       INSERT INTO SEATS 
       
       -- this will be the value of the first seatHold created when the 
       -- DBSchema script is run, which will be the Zebra Movie's seathold.
       VALUES( SEAT_ID_SEQ.NEXTVAL, (theater_row_letters(r) || i) , 'A', 1000 );

       
      END LOOP;
      
    end loop;
end;