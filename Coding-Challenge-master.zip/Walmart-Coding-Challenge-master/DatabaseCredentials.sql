CREATE USER Theater IDENTIFIED BY D4werdesgr8;
grant connect, resource to Theater;